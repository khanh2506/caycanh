<?php
$_['heading_title'] = 'Báo cáo trực tuyến';
$_['text_extension'] = 'Tiện ích mở rộng';
$_['text_success'] = 'Thành công: Bạn đã sửa đổi báo cáo khách hàng trực tuyến!';
$_['text_list'] = 'Danh sách trực tuyến';
$_['text_filter'] = 'Lọc';
$_['text_guest'] = 'Khách mời';
$_['column_ip'] = 'IP';
$_['column_customer'] = 'khách hàng';
$_['column_url'] = 'Trang cuối cùng đã truy cập';
$_['column_referer'] = 'Người giới thiệu';
$_['column_date_added'] = 'Lần nhấp cuối cùng';
$_['column_action'] = 'Hoạt động';
$_['entry_ip'] = 'IP';
$_['entry_customer'] = 'khách hàng';
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi báo cáo trực tuyến của khách hàng!';
