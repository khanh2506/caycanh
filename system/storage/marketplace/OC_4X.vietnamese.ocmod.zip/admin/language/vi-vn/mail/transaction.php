<?php
$_['text_subject'] = '%s - Tín dụng liên kết';
$_['text_received'] = 'Bạn đã nhận được %s tín dụng!';
$_['text_total'] = 'Tổng số tiền tín dụng của bạn hiện là %s.';
$_['text_credit'] = 'Tín dụng tài khoản của bạn có thể được khấu trừ từ lần mua hàng tiếp theo của bạn.';
