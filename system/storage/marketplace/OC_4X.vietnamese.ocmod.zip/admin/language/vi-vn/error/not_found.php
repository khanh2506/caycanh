<?php
// Phần mở đầu
$_['header_title'] = 'Không tìm thấy trang!';

// Chữ
$_['text_not_found'] = 'Không tìm thấy trang bạn đang tìm! Vui lòng liên hệ với quản trị viên của bạn nếu sự cố vẫn tiếp diễn. ';