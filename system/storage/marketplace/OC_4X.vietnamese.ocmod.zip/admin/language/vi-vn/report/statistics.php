<?php
$_['heading_title'] = 'Số liệu thống kê';
$_['text_success'] = 'Thành công: Bạn đã sửa đổi số liệu thống kê!';
$_['text_list'] = 'Danh sách thống kê';
$_['text_order_sale'] = 'Đặt hàng bán hàng';
$_['text_order_processing'] = 'Xử lý đơn hàng';
$_['text_order_complete'] = 'Đơn hàng đã hoàn thành';
$_['text_order_other'] = 'Đơn hàng Khác';
$_['text_returns'] = 'Lợi nhuận';
$_['text_customer'] = 'Khách hàng đang chờ phê duyệt';
$_['text_affiliate'] = 'Các chi nhánh đang chờ phê duyệt';
$_['text_product'] = 'Sản phẩm hết hàng';
$_['text_review'] = 'Đang chờ phê duyệt';
$_['column_name'] = 'Tên thống kê';
$_['column_value'] = 'Giá trị';
$_['column_action'] = 'Hoạt động';
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi số liệu thống kê!';
