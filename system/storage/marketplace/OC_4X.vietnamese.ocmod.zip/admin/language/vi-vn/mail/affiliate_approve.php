<?php
// Chữ
$_['text_subject'] = '% s - Tài khoản liên kết của bạn đã được kích hoạt!';
$_['text_welcome'] = 'Chào mừng và cảm ơn bạn đã đăng ký tại% s!';
$_['text_login'] = 'Tài khoản của bạn hiện đã được chấp thuận và bạn có thể đăng nhập bằng địa chỉ email và mật khẩu của mình bằng cách truy cập trang web của chúng tôi hoặc tại URL sau:';
$_['text_service'] = 'Sau khi đăng nhập, bạn sẽ có thể tạo mã theo dõi, theo dõi các khoản thanh toán hoa hồng và chỉnh sửa thông tin tài khoản của mình.';
$_['text_thanks'] = 'Cảm ơn,';