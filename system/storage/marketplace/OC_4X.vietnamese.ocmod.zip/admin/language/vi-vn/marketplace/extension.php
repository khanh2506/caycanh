<?php
$_['heading_title'] = 'Tiện ích mở rộng';
$_['text_success'] = 'Thành công: Bạn đã sửa đổi tiện ích mở rộng!';
$_['text_list'] = 'Danh sách tiện ích mở rộng';
$_['text_type'] = 'Chọn loại tiện ích mở rộng';
$_['text_filter'] = 'Lọc';
