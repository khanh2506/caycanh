<?php
// Phần mở đầu
$_['header_title'] = 'Quyền bị từ chối!';

// Chữ
$_['text_permission'] = 'Bạn không có quyền truy cập trang này, vui lòng liên hệ với quản trị viên hệ thống của bạn.';