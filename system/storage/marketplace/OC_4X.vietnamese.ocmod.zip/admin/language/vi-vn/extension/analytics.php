<?php
// Phần mở đầu
$_['header_title'] = 'Phân tích';

// Chữ
$_['text_success'] = 'Thành công: Bạn đã sửa đổi số liệu phân tích!';
$_['text_list'] = 'Danh sách phân tích';

// Cột
$_['column_name'] = 'Tên Analytics';
$_['column_status'] = 'Trạng thái';
$_['column_action'] = 'Hành động';

// Lỗi
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi số liệu phân tích!';
$_['error_extension'] = 'Cảnh báo: Phần mở rộng không tồn tại!';