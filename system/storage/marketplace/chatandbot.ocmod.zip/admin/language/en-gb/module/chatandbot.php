<?php
$_['heading_title']  = 'Live chat and chatbot - ChatAndBot';
$_['text_extension'] = 'Extensions';
$_['text_success']   = 'Settings successfully changed!';
$_['text_edit']      = 'Module settings';
$_['plugin_id']   = 'Plugin ID';
$_['text_enabled']   = 'Enabled';
$_['text_disabled']   = 'Disabled';
$_['entry_status']   = 'Status';
$_['description_plugin_id']   = 'In your account on chatandbot.com copy the plugin id and paste it into this field.';
$_['text_home']   = 'Home';



