<?php
$_['heading_title']  = 'Онлайн чат и чат бот - ChatAndBot';
$_['text_extension'] = 'Расширения';
$_['text_success']   = 'Настройки успешно изменены!';
$_['text_edit']      = 'Настройки модуля';
$_['plugin_id']   = 'Идентификатор плагина';
$_['text_enabled']   = 'Включено';
$_['text_disabled']  = 'Отключено';
$_['entry_status']   = 'Статус';
$_['description_plugin_id']   = 'Из личного кабинета на сайте chatandbot.com скопируйте идентификатор плагина и вставьте в это поле';
$_['text_home']   = 'Главная';
 
