<?php
$_['text_success'] = 'Thành công: Bạn đã sửa đổi phiếu thưởng!';
$_['text_subject'] = 'Bạn đã được gửi một phiếu quà tặng từ %s';
$_['text_greeting'] = 'Xin chúc mừng, Bạn đã nhận được một Phiếu quà tặng trị giá %s';
$_['text_from'] = 'Giấy chứng nhận quà tặng này đã được gửi cho bạn bởi %s';
$_['text_message'] = 'Với một tin nhắn nói rằng';
$_['text_redeem'] = 'Để đổi Phiếu quà tặng này, hãy viết mã đổi quà là <b> %s </b>, sau đó nhấp vào liên kết bên dưới và mua sản phẩm bạn muốn sử dụng phiếu quà tặng này. Bạn có thể nhập mã chứng nhận quà tặng trên trang giỏ hàng trước khi nhấp vào thanh toán.';
$_['text_footer'] = 'Vui lòng trả lời email này nếu bạn có bất kỳ câu hỏi nào.';
$_['text_sent'] = 'Thành công: e-mail Phiếu quà tặng đã được gửi!';
