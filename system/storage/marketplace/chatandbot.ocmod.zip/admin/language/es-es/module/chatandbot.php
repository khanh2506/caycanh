<?php
$_['heading_title']  = 'Chat en vivo y chatbot - ChatAndBot';
$_['text_extension'] = 'Extensiones';
$_['text_success']   = '¡Configuración cambiada con éxito!';
$_['text_edit']      = 'Configuración del módulo';
$_['plugin_id']   = 'Plugin ID';
$_['text_enabled']   = 'Activado';
$_['text_disabled']  = 'Desactivado';
$_['entry_status']   = 'Estado';
$_['description_plugin_id']   = 'En su cuenta de chatandbot.com, copie plugin id y péguelo en este.';
$_['text_home']   = 'Inicio';
