<?php
// Phần mở đầu
$_['header_title'] = 'Captchas';

// Chữ
$_['text_success'] = 'Thành công: Bạn đã sửa đổi hình ảnh xác thực!';
$_['text_list'] = 'Danh sách Captcha';

// Cột
$_['column_name'] = 'Tên Captcha';
$_['column_status'] = 'Trạng thái';
$_['column_action'] = 'Hành động';

// Lỗi
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi hình ảnh xác thực!';
$_['error_extension'] = 'Cảnh báo: Phần mở rộng không tồn tại!';