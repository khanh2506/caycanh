<?php
// Phần mở đầu
$_['header_title'] = 'Tổng đơn hàng';

// Chữ
$_['text_success'] = 'Thành công: Bạn đã sửa đổi tổng số!';

// Cột
$_['column_name'] = 'Tổng Đơn hàng';
$_['column_status'] = 'Trạng thái';
$_['column_sort_order'] = 'Sắp xếp Thứ tự';
$_['column_action'] = 'Hành động';

// Lỗi
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi tổng!';
$_['error_extension'] = 'Cảnh báo: Phần mở rộng không tồn tại!';