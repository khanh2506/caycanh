<?php
$_['heading_title'] = 'API thị trường OpenCart';
$_['text_success'] = 'Thành công: Bạn đã sửa đổi thông tin API của mình!';
$_['text_signup'] = 'Vui lòng nhập thông tin API OpenCart của bạn mà bạn có thể lấy <a href="https://www.opencart.com/index.php?route=account/store" target="_blank" class="alert-link"> tại đây < / a>.';
$_['entry_username'] = 'tên tài khoản';
$_['entry_secret'] = 'Bí mật';
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi API thị trường!';
$_['error_username'] = 'Tên người dùng được yêu cầu!';
$_['error_secret'] = 'Yêu cầu bí mật!';
