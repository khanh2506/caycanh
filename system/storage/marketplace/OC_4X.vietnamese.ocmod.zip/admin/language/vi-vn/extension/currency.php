<?php
// Phần mở đầu
$_['header_title'] = 'Tỷ giá tiền tệ';

// Chữ
$_['text_success'] = 'Thành công: Bạn đã sửa đổi tỷ giá tiền tệ!';
$_['text_list'] = 'Danh sách tỷ giá tiền tệ';

// Cột
$_['column_name'] = 'Tên tỷ giá tiền tệ';
$_['column_status'] = 'Trạng thái';
$_['column_action'] = 'Hành động';

// Lỗi
$_['error_permission'] = 'Cảnh báo: Bạn không được phép sửa đổi tỷ giá tiền tệ!';
$_['error_extension'] = 'Cảnh báo: Phần mở rộng không tồn tại!';